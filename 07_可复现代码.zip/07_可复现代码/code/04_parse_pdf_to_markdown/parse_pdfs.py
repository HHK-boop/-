from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[2]
LIST_PATH = ROOT / "company_lists" / "week1_public_samples.csv"
PDF_DIR = ROOT / "raw_pdfs"
TEXT_DIR = ROOT / "outputs" / "week1_parsed_texts"
LOG_PATH = ROOT / "logs" / "parse_log.csv"


def read_rows() -> list[dict[str, str]]:
    with LIST_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_rows(rows: list[dict[str, str]]) -> None:
    with LIST_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def parse_pdf(pdf_path: Path) -> tuple[str, int, str]:
    reader = PdfReader(str(pdf_path))
    parts = []
    errors = []
    for idx, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception as exc:
            text = ""
            errors.append(f"page {idx}: {exc}")
        parts.append(f"\n\n<!-- page:{idx} -->\n\n{text}")
    return "\n".join(parts), len(reader.pages), "; ".join(errors)


def main() -> None:
    TEXT_DIR.mkdir(parents=True, exist_ok=True)
    rows = read_rows()
    logs = []
    for row in rows:
        code = row["stock_code"]
        file_name = f"{row['sample_id']}_{code}.pdf"
        pdf_path = PDF_DIR / file_name
        text_path = TEXT_DIR / f"{row['sample_id']}_{code}.txt"
        status = "fail"
        error = ""
        page_count = ""
        if row.get("download_status") != "success":
            error = "download_status is not success"
        else:
            try:
                text, pages, parse_errors = parse_pdf(pdf_path)
                page_count = str(pages)
                text_path.write_text(text, encoding="utf-8")
                status = "partial" if parse_errors else "success"
                error = parse_errors
            except Exception as exc:
                error = str(exc)
        row["parse_status"] = status
        logs.append(
            {
                "company_name": row["company_name"],
                "stock_code": code,
                "file_name": file_name,
                "parser": "pypdf",
                "parse_time": datetime.now().isoformat(timespec="seconds"),
                "page_count": page_count,
                "markdown_path": str(text_path.relative_to(ROOT)) if text_path.exists() else "",
                "status": status,
                "error_message": error,
            }
        )
    with LOG_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "company_name",
                "stock_code",
                "file_name",
                "parser",
                "parse_time",
                "page_count",
                "markdown_path",
                "status",
                "error_message",
            ],
        )
        writer.writeheader()
        writer.writerows(logs)
    write_rows(rows)
    print(f"Wrote {LOG_PATH}")


if __name__ == "__main__":
    main()
