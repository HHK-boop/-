from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
LIST_PATH = ROOT / "company_lists" / "week1_public_samples.csv"
JSON_DIR = ROOT / "outputs" / "week1_sample_json"
LOG_PATH = ROOT / "logs" / "validation_log.csv"


REQUIRED_COMPANY_FIELDS = [
    "company_name",
    "stock_code",
    "exchange",
    "board",
    "listing_date",
    "prospectus_title",
    "prospectus_url",
    "prospectus_version",
    "prospectus_date",
]


def read_rows() -> list[dict[str, str]]:
    with LIST_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_rows(rows: list[dict[str, str]]) -> None:
    with LIST_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def validate_json(path: Path) -> tuple[str, list[str], list[str], list[str], str]:
    missing = []
    type_errors = []
    logic_errors = []
    review_required = "no"
    if not path.exists():
        return "fail", ["json file missing"], [], [], "yes"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return "fail", [], [f"json parse error: {exc}"], [], "yes"

    company = data.get("company")
    events = data.get("financing_events")
    processing = data.get("processing")
    processing_status = data.get("processing_status", {})

    if not isinstance(company, dict):
        type_errors.append("company is not object")
    else:
        for field in REQUIRED_COMPANY_FIELDS:
            if not company.get(field):
                missing.append(f"company.{field}")

    if not isinstance(events, list):
        type_errors.append("financing_events is not list")
    elif not events:
        logic_errors.append("no financing events extracted")
        review_required = "yes"
    else:
        for i, event in enumerate(events, start=1):
            if not event.get("evidence_text"):
                missing.append(f"event[{i}].evidence_text")
            if not event.get("source_page") and not event.get("source_section"):
                missing.append(f"event[{i}].source_page_or_section")
            if event.get("disclosed_round") != "未披露" and not event.get("evidence_text"):
                logic_errors.append(f"event[{i}] has round without evidence")
            if event.get("confidence") == "low" or not event.get("investors"):
                review_required = "yes"

    if not isinstance(processing, dict):
        type_errors.append("processing is not object")
    if processing_status.get("manual_review_required") == "yes":
        review_required = "yes"

    status = "pass" if not missing and not type_errors and not logic_errors else "revise"
    return status, missing, type_errors, logic_errors, review_required


def main() -> None:
    rows = read_rows()
    logs = []
    for row in rows:
        code = row["stock_code"]
        json_path = JSON_DIR / f"{row['sample_id']}_{code}.json"
        status, missing, type_errors, logic_errors, review_required = validate_json(json_path)
        row["review_status"] = status if status == "pass" else "revise"
        logs.append(
            {
                "company_name": row["company_name"],
                "stock_code": code,
                "json_path": str(json_path.relative_to(ROOT)) if json_path.exists() else "",
                "validation_status": status,
                "missing_fields": "; ".join(missing),
                "type_errors": "; ".join(type_errors),
                "logic_errors": "; ".join(logic_errors),
                "review_required": review_required,
            }
        )
    with LOG_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "company_name",
                "stock_code",
                "json_path",
                "validation_status",
                "missing_fields",
                "type_errors",
                "logic_errors",
                "review_required",
            ],
        )
        writer.writeheader()
        writer.writerows(logs)
    write_rows(rows)
    print(f"Wrote {LOG_PATH}")


if __name__ == "__main__":
    main()
