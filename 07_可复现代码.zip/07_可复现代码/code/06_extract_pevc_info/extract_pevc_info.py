from __future__ import annotations

import csv
import json
import re
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
LIST_PATH = ROOT / "company_lists" / "week1_public_samples.csv"
CANDIDATE_DIR = ROOT / "outputs" / "week1_candidate_texts"
JSON_DIR = ROOT / "outputs" / "week1_sample_json"
LOG_PATH = ROOT / "logs" / "extraction_log.csv"

EVENT_KEYWORDS = ["增资", "股权转让", "认购", "出资", "投资协议", "外部投资", "私募基金", "创业投资"]

KNOWN_SHORT_NAMES = [
    "黑龙江融汇工创创业投资企业（有限合伙）",
    "融汇工创",
    "稳正景明",
    "长泽创投",
    "第一美亚基金",
    "复星惟盈",
    "国寿疌泉",
    "华泰大健康一号",
    "华泰大健康二号",
    "高新同华",
    "海佳同康",
    "苏州敦行",
    "骏耀投资",
    "道兴投资",
    "临港投资",
    "鸿迪投资",
    "珠海拓域",
    "深创投",
    "华金同达",
    "领誉基石",
    "中证投资",
    "金石智娱",
    "朗玛六号",
    "天正投资",
    "朗玛五号",
    "深圳麦高",
    "朗玛九号",
    "德朴投资",
    "朗玛十四号",
    "利得鑫投",
    "汇智同裕",
    "华金创盈",
    "威明投资",
    "知盛投资",
    "厦门富凯",
    "伊敦传媒",
    "芜湖旷沄",
    "威明投资",
    "广东禾一泽成私募基金管理有限公司",
]

GOOD_NAME_TERMS = [
    "投资",
    "基金",
    "创投",
    "资本",
    "合伙",
    "私募",
    "国寿",
    "复星",
    "华泰",
    "深创投",
    "华金",
    "中证",
    "金石",
    "基石",
    "朗玛",
    "德朴",
    "利得",
    "同裕",
    "融汇",
]

BAD_NAME_TERMS = [
    "招股说明书",
    "发行人",
    "本次发行",
    "注册资本",
    "实收资本",
    "资本公积",
    "验资报告",
    "整体变更",
    "报告期",
    "序号",
    "合计",
    "股东名称",
    "出资额",
    "出资比例",
    "持股比例",
    "转让价格",
    "转让金额",
    "认购金额",
    "认购方式",
    "现金",
    "source",
    "是否属于",
    "战略投资者",
    "入股原因",
    "不存在",
    "承诺",
    "协议",
    "确认",
    "有权",
    "要求",
    "约定",
    "签署",
    "看好",
    "未来",
    "新增股东不",
    "依法",
    "存续",
    "经理",
    "主管",
    "总监",
    "销售部",
    "财务",
    "运营",
    "生产部",
    "设备部",
    "工程技术中心",
    "部门",
    "退休",
    "董事会秘书",
    "研究所",
    "职工",
    "分厂",
    "工艺创新室",
    "市场部",
    "厂长",
    "所长",
    "主任",
    "管理员",
    "管理室",
    "事务部",
    "部长",
    "品管部",
    "员工",
    "根据",
    "本企业",
    "前述",
    "于20",
    "在中国",
    "备案",
    "编码",
    "扩大资本",
    "包括",
    "应按时",
    "未经",
    "第三方",
    "普通合伙人",
    "有限合伙人",
]


def read_rows() -> list[dict[str, str]]:
    with LIST_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_rows(rows: list[dict[str, str]]) -> None:
    with LIST_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def to_number(text: str | None) -> float | None:
    if not text:
        return None
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return None


def compact(text: str, limit: int = 1400) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


def event_type(snippet: str) -> str:
    if "增资" in snippet and "股权转让" in snippet:
        return "增资及股权转让"
    if "股权转让" in snippet:
        return "股权转让"
    if "定向发行" in snippet or "认购" in snippet:
        return "定向发行/认购"
    if "增资" in snippet:
        return "增资"
    return "其他"


def investor_type(name: str) -> tuple[str, str]:
    if any(k in name for k in ["员工", "持股平台", "咨询", "管理中心"]):
        return "员工持股平台/持股平台", "uncertain"
    if any(k in name for k in ["政府", "国有", "产业", "引导"]):
        return "政府基金/产业资本", "uncertain"
    if any(k in name for k in ["创业投资", "创投", "私募", "股权投资", "投资基金", "基金", "资本", "深创投"]):
        return "VC/PE", "yes"
    if any(k in name for k in ["华金", "中证", "金石", "基石", "朗玛", "德朴", "利得", "同裕", "国寿", "复星", "华泰"]):
        return "VC/PE", "uncertain"
    if "有限公司" in name or "有限合伙" in name:
        return "机构投资者", "uncertain"
    return "无法判断", "uncertain"


def clean_name(name: str) -> str:
    name = re.sub(r"\s+", "", name)
    name = re.sub(r"^[0-9一二三四五六七八九十、.．]+", "", name)
    name = name.strip("，。；；：:、[]【】<>《》- ")
    return name


def is_good_name(name: str) -> bool:
    if not name or len(name) < 2 or len(name) > 38:
        return False
    if any(bad in name for bad in BAD_NAME_TERMS):
        return False
    if name in KNOWN_SHORT_NAMES:
        return True
    if any(good in name for good in GOOD_NAME_TERMS):
        return True
    if re.fullmatch(r"[A-Z][A-Za-z0-9 ]{2,20}", name):
        return True
    return False


def add_name(names: list[str], name: str) -> None:
    name = clean_name(name)
    if not is_good_name(name):
        return
    if name not in names:
        names.append(name)


def find_page(snippet: str) -> str:
    match = re.search(r"source_page=(\d+)", snippet)
    return match.group(1) if match else ""


def find_section(snippet: str) -> str:
    match = re.search(r"source_section=([^\n]*)", snippet)
    return match.group(1).strip() if match else ""


def find_amount(snippet: str) -> float | None:
    patterns = [
        r"募集\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s*元",
        r"总额\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s*元",
        r"人民币\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s*亿\s*元",
        r"人民币\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s*万\s*元",
        r"对价\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s*万\s*元",
        r"增资金额\s*（?万元）?.{0,120}?([0-9][0-9,]*(?:\.[0-9]+)?)",
        r"转让金额\s*（?万\s*元）?.{0,120}?([0-9][0-9,]*(?:\.[0-9]+)?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, snippet)
        if not match:
            continue
        value = to_number(match.group(1))
        if value is None:
            continue
        if "亿元" in match.group(0):
            return value * 10000
        if ("元" in match.group(0) and "万元" not in match.group(0)) or value > 100000:
            return round(value / 10000, 4)
        return value
    return None


def find_ratio(snippet: str) -> float | None:
    match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*%", snippet)
    return to_number(match.group(1)) if match else None


def find_date(snippet: str) -> str:
    match = re.search(r"(?:19|20)\d{2}\s*年\s*\d{1,2}\s*月\s*(?:\d{1,2}\s*日)?|(?:19|20)\d{2}-\d{1,2}-\d{1,2}", snippet)
    return re.sub(r"\s+", "", match.group(0)) if match else ""


def find_investor_names(text: str) -> list[str]:
    names: list[str] = []
    normalized = re.sub(r"\s+", "", text)

    for known in KNOWN_SHORT_NAMES:
        if known in normalized:
            add_name(names, known)

    long_patterns = [
        r"[\u4e00-\u9fa5A-Za-z0-9（）()·]{2,36}?(?:创业投资企业（有限合伙）|创业投资企业|创业投资中心|股权投资基金|投资基金|产业基金|投资中心|投资合伙企业|投资管理合伙企业|投资管理有限公司|投资有限公司|资本管理有限公司|私募基金管理有限公司|有限合伙)",
    ]
    for pattern in long_patterns:
        for match in re.findall(pattern, normalized):
            add_name(names, match)

    for line in text.splitlines():
        line = re.sub(r"\s+", " ", line).strip()
        if not re.match(r"^\d+\s+", line):
            continue
        if any(h in line for h in ["序号", "合计", "注："]):
            continue
        prefix_match = re.match(r"^\d+\s+(.{2,70}?)\s+[0-9][0-9,]*(?:\.[0-9]+)?(?:\s|$)", line)
        if not prefix_match:
            continue
        prefix = clean_name(prefix_match.group(1))
        for known in KNOWN_SHORT_NAMES:
            if known in prefix:
                add_name(names, known)
        if re.search(r"(创业投资企业|股权投资基金|投资基金|投资管理有限公司|投资有限公司|资本管理有限公司|私募基金管理有限公司|有限合伙)$", prefix):
            add_name(names, prefix)

    filtered: list[str] = []
    for name in names:
        if any(name != other and name in other and len(name) < len(other) for other in names):
            continue
        filtered.append(name)
    return filtered[:8]


def find_investors(text: str) -> list[dict[str, object]]:
    investors = []
    for name in find_investor_names(text):
        itype, is_pevc = investor_type(name)
        investors.append(
            {
                "investor_original_name": name,
                "investor_short_name": "",
                "investor_type": itype,
                "is_pevc": is_pevc,
                "investment_amount": None,
                "shares_acquired": None,
                "shareholding_ratio_after_event": None,
                "exit_status_before_ipo": "无法判断",
            }
        )
    return investors


def extract_events(candidate_text: str) -> list[dict[str, object]]:
    blocks = re.split(r"===== candidate \d+ =====", candidate_text)
    events = []
    seen = set()
    for block in blocks:
        if not any(k in block for k in EVENT_KEYWORDS):
            continue
        evidence = compact(block)
        key = evidence[:220]
        if key in seen:
            continue
        seen.add(key)
        investors = find_investors(block)
        events.append(
            {
                "event_order": len(events) + 1,
                "event_date": find_date(block),
                "date_type": "未说明",
                "event_type": event_type(block),
                "disclosed_round": "未披露",
                "inferred_round": "",
                "round_inference_basis": "",
                "total_investment_amount": find_amount(block),
                "currency": "CNY",
                "share_price": None,
                "equity_ratio": find_ratio(block),
                "pre_money_valuation": None,
                "post_money_valuation": None,
                "valuation_basis": "",
                "investors": investors,
                "source_section": find_section(block),
                "source_page": find_page(block),
                "evidence_text": evidence,
                "confidence": "medium" if investors else "low",
            }
        )
        if len(events) >= 3:
            break
    return events


def main() -> None:
    JSON_DIR.mkdir(parents=True, exist_ok=True)
    rows = read_rows()
    logs = []
    for row in rows:
        code = row["stock_code"]
        candidate_path = CANDIDATE_DIR / f"{row['sample_id']}_{code}_candidates.txt"
        json_path = JSON_DIR / f"{row['sample_id']}_{code}.json"
        status = "fail"
        error = ""
        events: list[dict[str, object]] = []
        if row.get("locate_status") != "success":
            error = "locate_status is not success"
        elif not candidate_path.exists():
            error = "candidate text missing"
        else:
            try:
                candidate_text = candidate_path.read_text(encoding="utf-8", errors="ignore")
                events = extract_events(candidate_text)
                status = "success" if events else "partial"
            except Exception as exc:
                error = str(exc)
        if events:
            review_required = "yes" if any(event["confidence"] == "low" for event in events) else "no"
            data = {
                "company": {
                    "company_name": row["company_name"],
                    "stock_code": code,
                    "exchange": row["exchange"],
                    "board": row["board"],
                    "listing_date": row["listing_date"],
                    "prospectus_title": row["prospectus_title"],
                    "prospectus_url": row["prospectus_url"],
                    "prospectus_version": row["prospectus_version"],
                    "prospectus_date": row["prospectus_date"],
                },
                "financing_events": events,
                "processing": {
                    "download_status": row["download_status"],
                    "parse_status": row["parse_status"],
                    "locate_status": row["locate_status"],
                    "extract_status": status,
                    "review_status": "unchecked",
                    "notes": "规则抽取结果，保留证据页；未披露或无法确认的信息填空或null，需人工复核。",
                },
                "processing_status": {
                    "extraction_method": "rule_based_week1",
                    "manual_review_required": review_required,
                    "generated_at": datetime.now().isoformat(timespec="seconds"),
                },
            }
            json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        row["extract_status"] = status
        logs.append(
            {
                "company_name": row["company_name"],
                "stock_code": code,
                "candidate_text_path": str(candidate_path.relative_to(ROOT)) if candidate_path.exists() else "",
                "model_name": "rule_based_extractor",
                "prompt_version": "week1_v2_conservative_names",
                "json_path": str(json_path.relative_to(ROOT)) if json_path.exists() else "",
                "status": status,
                "event_count": len(events),
                "investor_count": sum(len(event.get("investors", [])) for event in events),
                "error_message": error,
                "extraction_time": datetime.now().isoformat(timespec="seconds"),
            }
        )
    with LOG_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "company_name",
                "stock_code",
                "candidate_text_path",
                "model_name",
                "prompt_version",
                "json_path",
                "status",
                "event_count",
                "investor_count",
                "error_message",
                "extraction_time",
            ],
        )
        writer.writeheader()
        writer.writerows(logs)
    write_rows(rows)
    print(f"Wrote {LOG_PATH}")


if __name__ == "__main__":
    main()
