from __future__ import annotations

import csv
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
LIST_PATH = ROOT / "company_lists" / "week1_public_samples.csv"
TEXT_DIR = ROOT / "outputs" / "week1_parsed_texts"
CANDIDATE_DIR = ROOT / "outputs" / "week1_candidate_texts"
LOG_PATH = ROOT / "logs" / "locate_log.csv"

KEYWORDS = [
    "历次增资",
    "股权转让",
    "股本形成",
    "股本演变",
    "历史沿革",
    "发行前股东",
    "股东情况",
    "外部投资者",
    "投资协议",
    "特殊投资条款",
    "私募基金",
    "创业投资",
    "增资",
    "认购",
    "股份锁定",
]


def read_rows() -> list[dict[str, str]]:
    with LIST_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_rows(rows: list[dict[str, str]]) -> None:
    with LIST_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def page_for_pos(text: str, pos: int) -> str:
    markers = list(re.finditer(r"<!-- page:(\d+) -->", text[:pos]))
    return markers[-1].group(1) if markers else ""


def section_for_pos(text: str, pos: int) -> str:
    window = text[max(0, pos - 1200) : pos]
    candidates = re.findall(r"(第[一二三四五六七八九十百\d]+[章节][^\n]{0,40}|[一二三四五六七八九十]+、[^\n]{0,40})", window)
    return candidates[-1].strip() if candidates else ""


def compact_excerpt(text: str, pos: int, width: int = 1800) -> str:
    start = max(0, pos - width // 2)
    end = min(len(text), pos + width)
    excerpt = text[start:end]
    return re.sub(r"\n{3,}", "\n\n", excerpt).strip()


def page_blocks(text: str) -> list[tuple[str, int, int, str]]:
    matches = list(re.finditer(r"<!-- page:(\d+) -->", text))
    blocks = []
    for idx, match in enumerate(matches):
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        blocks.append((match.group(1), match.start(), end, text[start:end]))
    return blocks


def score_page(page_text: str) -> tuple[int, str]:
    matched = [kw for kw in KEYWORDS if kw in page_text]
    score = 0
    for kw in matched:
        if kw in {"历次增资", "股权转让", "股本形成", "股本演变", "历史沿革"}:
            score += 5
        elif kw in {"发行前股东", "股东情况", "外部投资者", "投资协议", "特殊投资条款"}:
            score += 3
        else:
            score += 1
    return score, "、".join(matched[:5])


def main() -> None:
    CANDIDATE_DIR.mkdir(parents=True, exist_ok=True)
    rows = read_rows()
    logs = []
    for row in rows:
        code = row["stock_code"]
        text_path = TEXT_DIR / f"{row['sample_id']}_{code}.txt"
        candidate_path = CANDIDATE_DIR / f"{row['sample_id']}_{code}_candidates.txt"
        status = "fail"
        error = ""
        hit_count = 0
        if row.get("parse_status") not in {"success", "partial"}:
            error = "parse_status is not success/partial"
        elif not text_path.exists():
            error = "parsed text missing"
        else:
            text = text_path.read_text(encoding="utf-8", errors="ignore")
            page_hits = []
            for page, start, end, page_text in page_blocks(text):
                score, matched_keywords = score_page(page_text)
                if score > 0:
                    page_hits.append((score, page, start, end, matched_keywords, page_text))
            page_hits.sort(key=lambda item: (-item[0], int(item[1])))
            found = []
            for score, page, start, end, matched_keywords, page_text in page_hits[:8]:
                local_positions = [page_text.find(kw) for kw in KEYWORDS if kw in page_text]
                local_positions = [p for p in local_positions if p >= 0]
                local = min(local_positions) if local_positions else 0
                pos = start + local
                found.append((matched_keywords, pos, page, section_for_pos(text, pos), compact_excerpt(text, pos, width=2600)))
            hit_count = len(found)
            if found:
                blocks = [
                    f"company={row['company_name']}\nstock_code={code}\nsample_id={row['sample_id']}\n",
                ]
                for idx, (kw, pos, page, section, excerpt) in enumerate(found, start=1):
                    blocks.append(
                        "\n".join(
                            [
                                f"\n===== candidate {idx} =====",
                                f"matched_keyword={kw}",
                                f"source_page={page}",
                                f"source_section={section}",
                                f"start_position={pos}",
                                "evidence_excerpt:",
                                excerpt,
                            ]
                        )
                    )
                    logs.append(
                        {
                            "company_name": row["company_name"],
                            "stock_code": code,
                            "matched_keyword": kw,
                            "source_section": section,
                            "start_position": pos,
                            "end_position": pos + len(excerpt),
                            "candidate_text_path": str(candidate_path.relative_to(ROOT)),
                            "status": "success",
                            "error_message": "",
                        }
                    )
                candidate_path.write_text("\n".join(blocks), encoding="utf-8")
                status = "success"
            else:
                error = "no matched keywords"
                logs.append(
                    {
                        "company_name": row["company_name"],
                        "stock_code": code,
                        "matched_keyword": "",
                        "source_section": "",
                        "start_position": "",
                        "end_position": "",
                        "candidate_text_path": "",
                        "status": "fail",
                        "error_message": error,
                    }
                )
        row["locate_status"] = status
        row["notes"] = row.get("notes", "") + f" 候选文本命中数={hit_count}。"
    with LOG_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "company_name",
                "stock_code",
                "matched_keyword",
                "source_section",
                "start_position",
                "end_position",
                "candidate_text_path",
                "status",
                "error_message",
            ],
        )
        writer.writeheader()
        writer.writerows(logs)
    write_rows(rows)
    print(f"Wrote {LOG_PATH}")


if __name__ == "__main__":
    main()
