from __future__ import annotations

import csv
import time
from datetime import datetime
from pathlib import Path
from urllib import request


ROOT = Path(__file__).resolve().parents[2]
LIST_PATH = ROOT / "company_lists" / "week1_public_samples.csv"
PDF_DIR = ROOT / "raw_pdfs"
LOG_PATH = ROOT / "logs" / "download_log.csv"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"


def read_rows() -> list[dict[str, str]]:
    with LIST_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_rows(rows: list[dict[str, str]]) -> None:
    with LIST_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def download(url: str) -> bytes:
    req = request.Request(url, headers={"User-Agent": UA, "Referer": "https://money.finance.sina.com.cn/"})
    with request.urlopen(req, timeout=90) as resp:
        return resp.read()


def main() -> None:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    rows = read_rows()
    logs = []
    for row in rows:
        code = row["stock_code"]
        file_name = f"{row['sample_id']}_{code}.pdf"
        path = PDF_DIR / file_name
        status = "fail"
        error = ""
        size = 0
        try:
            if not row.get("prospectus_url"):
                raise ValueError("missing prospectus_url")
            content = download(row["prospectus_url"])
            size = len(content)
            if not content.startswith(b"%PDF"):
                status = "wrong_file"
                error = "downloaded content is not PDF header"
            else:
                path.write_bytes(content)
                status = "success"
        except Exception as exc:
            error = str(exc)
        row["download_status"] = status
        logs.append(
            {
                "company_name": row["company_name"],
                "stock_code": code,
                "prospectus_url": row.get("prospectus_url", ""),
                "file_name": file_name,
                "download_time": datetime.now().isoformat(timespec="seconds"),
                "status": status,
                "file_size": size,
                "error_message": error,
            }
        )
        time.sleep(0.5)
    with LOG_PATH.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "company_name",
                "stock_code",
                "prospectus_url",
                "file_name",
                "download_time",
                "status",
                "file_size",
                "error_message",
            ],
        )
        writer.writeheader()
        writer.writerows(logs)
    write_rows(rows)
    print(f"Wrote {LOG_PATH}")


if __name__ == "__main__":
    main()
