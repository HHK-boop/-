# URL获取说明

本周为了保持样本清单和URL字段同步，公告页检索与PDF链接解析写在：

```text
code/01_build_company_list/build_week1_company_list.py
```

该脚本会生成或更新：

```text
company_lists/week1_public_samples.csv
```

其中包含 `source_page_url`、`prospectus_title`、`prospectus_url`、`prospectus_date` 等字段。后续如果扩展为批量样本，可将URL检索逻辑单独拆到本目录。
