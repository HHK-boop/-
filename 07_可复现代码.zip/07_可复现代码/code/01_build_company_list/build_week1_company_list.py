from __future__ import annotations

import csv
import re
from pathlib import Path
from urllib import request


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "company_lists" / "week1_public_samples.csv"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"


SAMPLES = [
    {
        "sample_id": "MB001",
        "company_name": "包头天和磁材科技股份有限公司",
        "stock_code": "603072",
        "exchange": "SSE",
        "board": "主板",
        "short_name": "天和磁材",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；主板；重点检查历史沿革、增资、股权转让信息。",
    },
    {
        "sample_id": "MB002",
        "company_name": "上海友升铝业股份有限公司",
        "stock_code": "603418",
        "exchange": "SSE",
        "board": "主板",
        "short_name": "友升股份",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；主板；重点检查文件版本和章节定位。",
    },
    {
        "sample_id": "GEM001",
        "company_name": "黄山谷捷股份有限公司",
        "stock_code": "301581",
        "exchange": "SZSE",
        "board": "创业板",
        "short_name": "黄山谷捷",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；创业板；重点区分正式招股说明书与上市公告书。",
    },
    {
        "sample_id": "GEM002",
        "company_name": "云汉芯城（上海）互联网科技股份有限公司",
        "stock_code": "301563",
        "exchange": "SZSE",
        "board": "创业板",
        "short_name": "云汉芯城",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；创业板；重点识别外部投资者和股东结构。",
    },
    {
        "sample_id": "STAR001",
        "company_name": "苏州赛分科技股份有限公司",
        "stock_code": "688758",
        "exchange": "SSE",
        "board": "科创板",
        "short_name": "赛分科技",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；科创板；重点练习多轮融资和股权演变字段。",
    },
    {
        "sample_id": "STAR002",
        "company_name": "影石创新科技股份有限公司",
        "stock_code": "688775",
        "exchange": "SSE",
        "board": "科创板",
        "short_name": "影石创新",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；科创板；重点练习VC/PE投资方识别与证据保留。",
    },
    {
        "sample_id": "BSE001",
        "company_name": "常州三协电机股份有限公司",
        "stock_code": "920100",
        "exchange": "BSE",
        "board": "北交所",
        "short_name": "三协电机",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；北交所；重点练习私募基金股东、创投企业识别。",
    },
    {
        "sample_id": "BSE002",
        "company_name": "哈尔滨岛田大鹏工业股份有限公司",
        "stock_code": "920091",
        "exchange": "BSE",
        "board": "北交所",
        "short_name": "大鹏工业",
        "source_platform": "新浪财经公告库",
        "notes": "公共训练样本；北交所；重点练习多版本招股书识别。",
    },
]


FIELDS = [
    "sample_id",
    "company_name",
    "stock_code",
    "exchange",
    "board",
    "listing_date",
    "ipo_year",
    "source_platform",
    "source_page_url",
    "prospectus_title",
    "prospectus_url",
    "prospectus_version",
    "prospectus_date",
    "download_status",
    "parse_status",
    "locate_status",
    "extract_status",
    "review_status",
    "notes",
]


def fetch_text(url: str, encoding: str = "gbk") -> str:
    req = request.Request(url, headers={"User-Agent": UA})
    with request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
    return raw.decode(encoding, errors="ignore")


def absolute_sina_url(href: str) -> str:
    if href.startswith("http"):
        return href
    return "https://money.finance.sina.com.cn" + href


def extract_pdf_url(detail_url: str) -> str:
    text = fetch_text(detail_url)
    matches = re.findall(r"https?://[^'\"<>]+?\.PDF", text, flags=re.I)
    return matches[0] if matches else ""


def find_prospectus(code: str) -> tuple[str, str, str, str]:
    list_url = f"https://money.finance.sina.com.cn/corp/go.php/vCB_Bulletin/stockid/{code}/page_type/zgsmsyxs.phtml"
    text = fetch_text(list_url)
    links = re.findall(
        r"(\d{4}-\d{2}-\d{2})&nbsp;<a target='_blank' href='([^']+)'>([^<]+)</a>",
        text,
    )
    preferred = None
    for disclosure_date, href, title in links:
        if "招股说明书" in title and "意向书" not in title:
            preferred = (disclosure_date, href, title)
            break
    if not preferred:
        for disclosure_date, href, title in links:
            if "招股" in title:
                preferred = (disclosure_date, href, title)
                break
    if not preferred:
        return list_url, "", "", ""
    disclosure_date, href, title = preferred
    detail_url = absolute_sina_url(href)
    pdf_url = extract_pdf_url(detail_url)
    return detail_url, title, pdf_url, disclosure_date


def find_listing_date(code: str) -> str:
    url = f"https://vip.stock.finance.sina.com.cn/corp/go.php/vISSUE_NewStock/stockid/{code}.phtml"
    try:
        text = fetch_text(url)
    except Exception:
        return ""
    match = re.search(r"<strong>上市日期</strong></td><td>(\d{4}-\d{2}-\d{2})</td>", text)
    return match.group(1) if match else ""


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for item in SAMPLES:
        code = item["stock_code"]
        source_page_url, title, pdf_url, prospectus_date = find_prospectus(code)
        listing_date = find_listing_date(code)
        version = "正式稿" if "招股说明书" in title and "意向书" not in title else "待复核"
        row = {
            "sample_id": item["sample_id"],
            "company_name": item["company_name"],
            "stock_code": code,
            "exchange": item["exchange"],
            "board": item["board"],
            "listing_date": listing_date,
            "ipo_year": listing_date[:4] if listing_date else "",
            "source_platform": item["source_platform"],
            "source_page_url": source_page_url,
            "prospectus_title": title,
            "prospectus_url": pdf_url,
            "prospectus_version": version,
            "prospectus_date": prospectus_date,
            "download_status": "pending",
            "parse_status": "pending",
            "locate_status": "pending",
            "extract_status": "pending",
            "review_status": "unchecked",
            "notes": item["notes"] + " 来源入口需提交前用交易所/巨潮复核。",
        }
        rows.append(row)
    with OUT.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
